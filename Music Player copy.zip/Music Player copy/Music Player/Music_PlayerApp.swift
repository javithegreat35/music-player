//
//  Music_PlayerApp.swift
//  Music Player
//
//  Created by Javier Canedo on 2/25/21.
//

import SwiftUI

@main
struct Music_PlayerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
